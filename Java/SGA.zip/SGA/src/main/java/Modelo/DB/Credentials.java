package Modelo.DB;

public class Credentials {

    final String url = "jdbc:mysql://localhost:3306/galeriadb";
    final String user = "root";
    final String pass =  "130213";
}
