package Frontend.CoreApp.Funciones;

import javax.swing.*;

public class UserControl extends JPanel {
}
